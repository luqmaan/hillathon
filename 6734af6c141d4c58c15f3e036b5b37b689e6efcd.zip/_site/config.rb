http_path = "/"
css_dir = "assets/css"
sass_dir = "assets/scss"
images_dir = "assets/images"
javascripts_dir = "assets/js"

require "sassy_noise"
require "susy"
require "bourbon"
line_comments = false